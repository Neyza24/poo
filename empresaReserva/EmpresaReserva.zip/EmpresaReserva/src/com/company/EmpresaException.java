package com.company;

public class EmpresaException extends Exception {

    public EmpresaException(String mensaje) {
        super(mensaje);
    }
}
