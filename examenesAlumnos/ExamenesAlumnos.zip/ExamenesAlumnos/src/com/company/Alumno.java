package com.company;

public class Alumno {
    private String nombre;
    private String apellido;
    private Integer legajo;

    public Alumno( String nombre, String apellido, Integer legajo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.legajo = legajo;
    }


}
