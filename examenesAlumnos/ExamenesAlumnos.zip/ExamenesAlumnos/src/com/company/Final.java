package com.company;

public class Final extends Examen implements Comparable{
    private Double notaOral;
    private Double notaEscrita;
    private String descripcionOral;

    public Final(Alumno alumno, String titulo, String enunciado, Double nota, Double notaOral,Double notaEscrita, String descripcionOral) {
        super(alumno, titulo, enunciado, nota);
        this.notaOral = notaOral;
        this.notaEscrita = notaEscrita;
        this.descripcionOral = descripcionOral;
    }


    @Override
    public int compareTo(Object otraNotaFinal) {
        //Casteamos para poder comparar//
        Final otroExamen = (Final) otraNotaFinal;

        Double notaPromedioFinal1 = (this.getNotaEscrita() + this.getNotaOral()) / 2;
        Double notaPromedioFinal2 = (otroExamen.getNotaEscrita() + otroExamen.getNotaOral()) / 2;

        if(notaPromedioFinal1 > notaPromedioFinal2) {
            return 1;
        }
        if(notaPromedioFinal1 < notaPromedioFinal2) {
            return -1;
        }
        return 0;
    }

    public Double getNotaOral() {
        return this.notaOral;
    }

    public Double getNotaEscrita() {
        return this.notaEscrita;
    }
}
