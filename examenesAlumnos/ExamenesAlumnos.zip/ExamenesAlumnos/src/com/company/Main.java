package com.company;

public class Main {
    public static void main(String[] args) {
        System.out.println("-----------------------------Datos alumno/a----------------------------- ");
        Alumno alumno1 = new Alumno("Juan", "Valencia", 2345);
        System.out.println(alumno1);

        System.out.println("---------------------Datos sobre examen parcial--------------------------");

        Parcial parcial1 = new Parcial(alumno1, "Examen POO", "Relizar la...", 3.2, 2);
        System.out.println(parcial1.estaAprobado());
        System.out.println("La nota de su parcial fue: " + parcial1.getNota());
        parcial1.recuperacionExamen(3.5);
        System.out.println("Tiene " + parcial1.numeroReintentos() + " reintentos");




        System.out.println("------------------------------Datos examen final----------------------------");
        Final final1 = new Final(alumno1, "Examen de POO", "Se debe generar un UML para la siguiente consigna", 4.5, 4.3, 3.2,"Tenemos una clase padre Examen y una clase hija final");
        Final final2 = new Final(alumno1, "Examen de POO", "Se debe generar un UML para la siguiente consigna", 4.5, 4.3, 4.2,"Tenemos una clase padre Examen y una clase hija final");
        System.out.println(final1.estaAprobado());
        System.out.println(final2.estaAprobado());
        System.out.println(final1.compareTo(final2));










    }
}
