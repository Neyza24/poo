package com.company;

public class Parcial extends Examen{
    private Integer numeroDeUnidad;
    private Integer numeroDeReintentos = 0;

    public Parcial(Alumno alumno, String titulo, String enunciado, Double nota, Integer numeroDeUnidad) {
        super(alumno, titulo, enunciado, nota);
        this.numeroDeUnidad = numeroDeUnidad;
    }

    public Integer numeroReintentos(){
            if(this.numeroDeUnidad <= 3) {
                return this.numeroDeReintentos = 3;
            } else /*if(this.numeroDeUnidad > 3)*/ {
                return this.numeroDeReintentos = 2;
            }
    }

    public void recuperacionExamen(double nota) {
        if(this.numeroDeReintentos <= 3){
            this.numeroDeReintentos--;
        }else{
            System.out.println("No es posible presentar más examenes");
        }

    }
}
